
export default new Map([
["src/content/docs/index.mdoc", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fdocs%2Findex.mdoc&astroContentModuleFlag=true")]]);
		