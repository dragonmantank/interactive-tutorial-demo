---
title: Something Else
description: An introduction to the onboarding tutorial
---

# Starter Tutorial

ome more steps

Here is some code:

```js
function demo() {
  // This is a comment
  console.log('Hello World');
}
```
